#pragma once

using namespace System;

public ref class User {
public:
   

    property String^ FullName;
    property String^ DOB;
    property int Address;  
    property int StartingMileage;
    property String^ Destination;
    property String^ StartTime;
    property String^ ReturnDate;
    property String^ StartingCondition;
    property int FuelLevel;
    property String^ TripReason;
};