#pragma once
#include "user.h"
#include "LogData.h"


namespace TripInformationcpp {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::Data::SqlClient;
	using namespace System::Windows::Forms;
	


	public ref class LogData : public System::Windows::Forms::Form
	{
	public:
		LogData(void)
		{
			InitializeComponent();
			

	
		}

	protected:
	
		!LogData()

		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^ Login;
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::Label^ label4;
	private: System::Windows::Forms::Label^ label5;
	private: System::Windows::Forms::Label^ label6;
	private: System::Windows::Forms::Label^ label7;
	private: System::Windows::Forms::Label^ label8;
	private: System::Windows::Forms::Label^ label9;
	private: System::Windows::Forms::Label^ label10;
	private: System::Windows::Forms::TextBox^ tbFullName;
	private: System::Windows::Forms::TextBox^ tbDOB;
	private: System::Windows::Forms::TextBox^ tbZip;
	private: System::Windows::Forms::TextBox^ tbDestination;
	private: System::Windows::Forms::TextBox^ tbStartTime;
	private: System::Windows::Forms::TextBox^ tbReturnDate;
	private: System::Windows::Forms::TextBox^ tbStartingMilege;
	private: System::Windows::Forms::TextBox^ tbStartingConditction;
	private: System::Windows::Forms::TextBox^ tbFuelLevel;
	private: System::Windows::Forms::TextBox^ tbTripReason;
	private: System::Windows::Forms::Button^ btnOk;
	private: System::Windows::Forms::Button^ btnClear;


	protected:

	private:
		
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		
		void InsertTripInformation() {
			String^ connString = GetConnectionString();
			SqlConnection^ sqlConn = gcnew SqlConnection(connString);
			try {
				sqlConn->Open();
				String^ sqlQuery = "INSERT INTO tripTracker (FullName, DOB, ZipCode, Destination, StartTime, ReturnDate, StartingMileage, StartingCondition, FuelLevel, TripReason) VALUES (@FullName, @DOB, @ZipCode, @Destination, @StartTime, @ReturnDate, @StartingMileage, @StartingCondition, @FuelLevel, @TripReason)";
				SqlCommand^ command = gcnew SqlCommand(sqlQuery, sqlConn);
				// Add parameters...
				if (command->ExecuteNonQuery() > 0) {
					MessageBox::Show("Data inserted successfully");
				}
				else {
					MessageBox::Show("Failed to insert data");
				}
			}
			catch (Exception^ ex) {
				MessageBox::Show("Error: " + ex->Message);
			}
			finally {
				sqlConn->Close();
			}
		}
		String^ GetConnectionString() {
			return "Data Source=RUSTY\\SQLEXPRESS;Initial Catalog=tripTracker;Integrated Security=True;Encrypt=True;Trust Server Certificate=True";
		}
	private: System::Void btnOk_Click(System::Object^ sender, System::EventArgs^ e) {
		if (ValidateInput()) {
			InsertTripInformation();
		}
	}
		   bool ValidateInput() {
			   if (String::IsNullOrWhiteSpace(tbFullName->Text) || String::IsNullOrWhiteSpace(tbDOB->Text) || String::IsNullOrWhiteSpace(tbZip->Text) ||
				   String::IsNullOrWhiteSpace(tbDestination->Text) || String::IsNullOrWhiteSpace(tbStartTime->Text) || String::IsNullOrWhiteSpace(tbReturnDate->Text) ||
				   String::IsNullOrWhiteSpace(tbStartingMilege->Text) || String::IsNullOrWhiteSpace(tbStartingConditction->Text) || String::IsNullOrWhiteSpace(tbFuelLevel->Text) ||
				   String::IsNullOrWhiteSpace(tbTripReason->Text)) {
				   MessageBox::Show("Please fill all the fields");
				   return false;
			   }
			   return true;
		   }
			private: System::Void btnClear_Click(System::Object^ sender, System::EventArgs^ e) {
		ClearForm();
	}
				   void ClearForm() {
					   tbFullName->Text = "";
					   tbDOB->Text = "";
					   tbZip->Text = "";
					   tbDestination->Text = "";
					   tbStartTime->Text = "";
					   tbReturnDate->Text = "";
					   tbStartingMilege->Text = "";
					   tbStartingConditction->Text = "";
					   tbFuelLevel->Text = "";
					   tbTripReason->Text = "";
				   }
		void InitializeComponent(void)
		{
			this->Login = (gcnew System::Windows::Forms::Label());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->label8 = (gcnew System::Windows::Forms::Label());
			this->label9 = (gcnew System::Windows::Forms::Label());
			this->label10 = (gcnew System::Windows::Forms::Label());
			this->tbFullName = (gcnew System::Windows::Forms::TextBox());
			this->tbDOB = (gcnew System::Windows::Forms::TextBox());
			this->tbZip = (gcnew System::Windows::Forms::TextBox());
			this->tbDestination = (gcnew System::Windows::Forms::TextBox());
			this->tbStartTime = (gcnew System::Windows::Forms::TextBox());
			this->tbReturnDate = (gcnew System::Windows::Forms::TextBox());
			this->tbStartingMilege = (gcnew System::Windows::Forms::TextBox());
			this->tbStartingConditction = (gcnew System::Windows::Forms::TextBox());
			this->tbFuelLevel = (gcnew System::Windows::Forms::TextBox());
			this->tbTripReason = (gcnew System::Windows::Forms::TextBox());
			this->btnOk = (gcnew System::Windows::Forms::Button());
			this->btnClear = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// Login
			// 
			this->Login->Location = System::Drawing::Point(104, 56);
			this->Login->Name = L"Login";
			this->Login->Size = System::Drawing::Size(943, 57);
			this->Login->TabIndex = 0;
			this->Login->Text = L"Login";
			this->Login->TextAlign = System::Drawing::ContentAlignment::MiddleCenter;
			this->Login->Click += gcnew System::EventHandler(this, &LogData::Login_Click);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(13, 224);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(159, 34);
			this->label1->TabIndex = 1;
			this->label1->Text = L"Full name";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Modern No. 20", 14, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(14, 297);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(186, 30);
			this->label2->TabIndex = 2;
			this->label2->Text = L"Date Of Birth";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(11, 362);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(127, 34);
			this->label3->TabIndex = 3;
			this->label3->Text = L"zip code";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(13, 439);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(176, 34);
			this->label4->TabIndex = 4;
			this->label4->Text = L"Destination";
			this->label4->Click += gcnew System::EventHandler(this, &LogData::label4_Click);
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(23, 519);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(166, 34);
			this->label5->TabIndex = 5;
			this->label5->Text = L"Start Time";
			this->label5->Click += gcnew System::EventHandler(this, &LogData::label5_Click);
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(11, 600);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(188, 34);
			this->label6->TabIndex = 6;
			this->label6->Text = L"Return Date";
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Location = System::Drawing::Point(500, 213);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(248, 34);
			this->label7->TabIndex = 7;
			this->label7->Text = L"Starting Mileage";
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->Location = System::Drawing::Point(500, 294);
			this->label8->Name = L"label8";
			this->label8->Size = System::Drawing::Size(299, 34);
			this->label8->TabIndex = 8;
			this->label8->Text = L"Starting Conditction";
			// 
			// label9
			// 
			this->label9->AutoSize = true;
			this->label9->Location = System::Drawing::Point(500, 362);
			this->label9->Name = L"label9";
			this->label9->Size = System::Drawing::Size(166, 34);
			this->label9->TabIndex = 9;
			this->label9->Text = L"Fuel Level";
			// 
			// label10
			// 
			this->label10->AutoSize = true;
			this->label10->Location = System::Drawing::Point(502, 439);
			this->label10->Name = L"label10";
			this->label10->Size = System::Drawing::Size(246, 34);
			this->label10->TabIndex = 10;
			this->label10->Text = L"Reason For Trip";
			// 
			// tbFullName
			// 
			this->tbFullName->Location = System::Drawing::Point(206, 224);
			this->tbFullName->Name = L"tbFullName";
			this->tbFullName->Size = System::Drawing::Size(288, 42);
			this->tbFullName->TabIndex = 11;
			// 
			// tbDOB
			// 
			this->tbDOB->Location = System::Drawing::Point(206, 294);
			this->tbDOB->Name = L"tbDOB";
			this->tbDOB->Size = System::Drawing::Size(287, 42);
			this->tbDOB->TabIndex = 12;
			// 
			// tbZip
			// 
			this->tbZip->Location = System::Drawing::Point(206, 362);
			this->tbZip->Name = L"tbZip";
			this->tbZip->Size = System::Drawing::Size(288, 42);
			this->tbZip->TabIndex = 13;
			// 
			// tbDestination
			// 
			this->tbDestination->Location = System::Drawing::Point(206, 439);
			this->tbDestination->Name = L"tbDestination";
			this->tbDestination->Size = System::Drawing::Size(290, 42);
			this->tbDestination->TabIndex = 14;
			// 
			// tbStartTime
			// 
			this->tbStartTime->Location = System::Drawing::Point(206, 516);
			this->tbStartTime->Name = L"tbStartTime";
			this->tbStartTime->Size = System::Drawing::Size(290, 42);
			this->tbStartTime->TabIndex = 15;
			// 
			// tbReturnDate
			// 
			this->tbReturnDate->Location = System::Drawing::Point(205, 600);
			this->tbReturnDate->Name = L"tbReturnDate";
			this->tbReturnDate->Size = System::Drawing::Size(288, 42);
			this->tbReturnDate->TabIndex = 16;
			// 
			// tbStartingMilege
			// 
			this->tbStartingMilege->Location = System::Drawing::Point(805, 205);
			this->tbStartingMilege->Name = L"tbStartingMilege";
			this->tbStartingMilege->Size = System::Drawing::Size(256, 42);
			this->tbStartingMilege->TabIndex = 17;
			// 
			// tbStartingConditction
			// 
			this->tbStartingConditction->Location = System::Drawing::Point(805, 291);
			this->tbStartingConditction->Name = L"tbStartingConditction";
			this->tbStartingConditction->Size = System::Drawing::Size(256, 42);
			this->tbStartingConditction->TabIndex = 18;
			// 
			// tbFuelLevel
			// 
			this->tbFuelLevel->Location = System::Drawing::Point(805, 369);
			this->tbFuelLevel->Name = L"tbFuelLevel";
			this->tbFuelLevel->Size = System::Drawing::Size(256, 42);
			this->tbFuelLevel->TabIndex = 19;
			// 
			// tbTripReason
			// 
			this->tbTripReason->Location = System::Drawing::Point(805, 439);
			this->tbTripReason->Name = L"tbTripReason";
			this->tbTripReason->Size = System::Drawing::Size(256, 42);
			this->tbTripReason->TabIndex = 20;
			// 
			// btnOk
			// 
			this->btnOk->Location = System::Drawing::Point(548, 593);
			this->btnOk->Name = L"btnOk";
			this->btnOk->Size = System::Drawing::Size(231, 54);
			this->btnOk->TabIndex = 21;
			this->btnOk->Text = L"Ok";
			this->btnOk->UseVisualStyleBackColor = true;
			this->btnOk->Click += gcnew System::EventHandler(this, &LogData::button1_Click);
			// 
			// btnClear
			// 
			this->btnClear->Location = System::Drawing::Point(785, 593);
			this->btnClear->Name = L"btnClear";
			this->btnClear->Size = System::Drawing::Size(210, 54);
			this->btnClear->TabIndex = 22;
			this->btnClear->Text = L"Clear";
			this->btnClear->UseVisualStyleBackColor = true;
			// 
			// LogData
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(19, 34);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::SystemColors::ActiveCaption;
			this->ClientSize = System::Drawing::Size(1163, 689);
			this->Controls->Add(this->btnClear);
			this->Controls->Add(this->btnOk);
			this->Controls->Add(this->tbTripReason);
			this->Controls->Add(this->tbFuelLevel);
			this->Controls->Add(this->tbStartingConditction);
			this->Controls->Add(this->tbStartingMilege);
			this->Controls->Add(this->tbReturnDate);
			this->Controls->Add(this->tbStartTime);
			this->Controls->Add(this->tbDestination);
			this->Controls->Add(this->tbZip);
			this->Controls->Add(this->tbDOB);
			this->Controls->Add(this->tbFullName);
			this->Controls->Add(this->label10);
			this->Controls->Add(this->label9);
			this->Controls->Add(this->label8);
			this->Controls->Add(this->label7);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->Login);
			this->Font = (gcnew System::Drawing::Font(L"Modern No. 20", 16, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->Margin = System::Windows::Forms::Padding(6, 5, 6, 5);
			this->Name = L"LogData";
			this->Text = L"Login Form";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	
public: User^ user = nullptr;

private: System::Void Login_Click(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void label5_Click(System::Object^ sender, System::EventArgs^ e) {
	}
private: System::Void label4_Click(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {
	// Declare variables
	String^ FullName = tbFullName->Text;
	String^ DOB = tbDOB->Text;
	String^ Zipcode = tbZip->Text;
	String^ Destination = tbDestination->Text;
	String^ StartTime = tbStartTime->Text;
	String^ ReturnDate = tbReturnDate->Text;
	String^ StartingMilegeStr = tbStartingMilege->Text;
	String^ StartingConditction = tbStartingConditction->Text;
	String^ FuelLevelStr = tbFuelLevel->Text;
	String^ TripReason = tbTripReason->Text;

	// Validation
	if (String::IsNullOrWhiteSpace(FullName) || String::IsNullOrWhiteSpace(DOB) || String::IsNullOrWhiteSpace(Zipcode) ||
		String::IsNullOrWhiteSpace(Destination) || String::IsNullOrWhiteSpace(StartTime) || String::IsNullOrWhiteSpace(ReturnDate) ||
		String::IsNullOrWhiteSpace(StartingMilegeStr) || String::IsNullOrWhiteSpace(StartingConditction) || String::IsNullOrWhiteSpace(FuelLevelStr) ||
		String::IsNullOrWhiteSpace(TripReason)) {
		MessageBox::Show("Please fill all the fields");
		return;
	}

	try {
		// Convert string inputs to appropriate types
		int address = Convert::ToInt32(Zipcode);
		int StartingMilege = Convert::ToInt32(StartingMilegeStr);
		int FuelLevel = Convert::ToInt32(FuelLevelStr);

		// Database Connection
		String^ connString = "Data Source=RUSTY\\SQLEXPRESS;Initial Catalog=tripTracker;Integrated Security=True;Encrypt=True;Trust Server Certificate=True";
		SqlConnection^ sqlConn = gcnew SqlConnection(connString);
		sqlConn->Open();

		// Insert Data with parameterized query
		String^ sqlQuery = "INSERT INTO tripTracker (FullName, DOB, address, Destination, StartTime, ReturnDate, StartingMilege, StartingConditction, FuelLevel, TripReason) VALUES (@FullName, @DOB, @address, @Destination, @StartTime, @ReturnDate, @StartingMilege, @StartingConditction, @FuelLevel, @TripReason)";
		SqlCommand^ command = gcnew SqlCommand(sqlQuery, sqlConn);

		// Add parameters
		command->Parameters->AddWithValue("@FullName", FullName);
		command->Parameters->AddWithValue("@DOB", DOB);
		command->Parameters->AddWithValue("@address", address);
		command->Parameters->AddWithValue("@Destination", Destination);
		command->Parameters->AddWithValue("@StartTime", StartTime);
		command->Parameters->AddWithValue("@ReturnDate", ReturnDate);
		command->Parameters->AddWithValue("@StartingMilege", StartingMilege);
		command->Parameters->AddWithValue("@StartingConditction", StartingConditction);
		command->Parameters->AddWithValue("@FuelLevel", FuelLevel);
		command->Parameters->AddWithValue("@TripReason", TripReason);

		int rowsAffected = command->ExecuteNonQuery();

		if (rowsAffected > 0) {
			// Data inserted successfully
			MessageBox::Show("Data inserted successfully");
		}
		else {
			MessageBox::Show("Failed to insert data");
		}

	

	}
	catch (Exception^ ex) {
		MessageBox::Show("Error: " + ex->Message);
	}
	//finally {
	//	sqlConn->Close();
	//}
}
};
}		
